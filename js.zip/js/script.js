//Variablen
let flippedCards = [];
let lockBoard = false;

let matches = 0;
let moves = 0;
const totalPairs = 10;

//10 Basis-Symbole definiert
const baseIcons = ["A", "B", "C","D","E", "F","G", "H", "I", "J"];

//Array verdoppelt damit jedes Symbol ein Paar hat
const cardIcons = baseIcons.concat(baseIcons);

console.log("Automatisierte Paare: ", cardIcons);

//einfache Shuffle Funktion 

function shuffleArray(arr) {
  arr.sort(function() {
    return 0.5 - Math.random()});
  console.log("Karten gemischt: ", arr);

}

//Task 2 Das Spielfeld wird dynamisch generiert 
//für jedes sybmol wird eine neue HTML card element gemacht
//Eventlistener ist verknüpft damit die Karten auf den Klick reagieren
function createBoard() {
  const board = document.getElementById("game-board");
  //Alle Karten im game-board werden entfernt
  board.innerHTML = "";

  for(const icon of cardIcons) {
    let card = document.createElement("div");
    console.log(icon);
    card.className = "cards";
    card.setAttribute("data-value", icon);
    card.textContent = "?";

    card.addEventListener("click", function() {
      flipCard(this);
      console.log("Karte geklickt, Wert:", this.getAttribute("data-value"));
      });
    board.appendChild(card);
  }
  console.log("Board erstellt mit" + cardIcons.length + "Karten.");
}
//Task 3 Flip & Match logic
function flipCard(card) {
  //Board bleibt gesperrt
  if (lockBoard) return;
  //Die gefundene Karte wird nicht nochmal angeklickt
  if(card.classList.contains("matched")) return; //prüft ob die CSS klasse gibt, wenn ja wird die Funktion sofort mit return beendet. Das verhindert das doppelte anklicken
  if(card.classList.contains("flipped")) return;
  starttimer();

  card.textContent = card.getAttribute("data-value");
  // die Karte wird optisch als offen markiert
  card.classList.add("flipped");
  console.log("Karte geklickt: " + card.getAttribute("data-value"));

  //Die Karte wird ins Array gespeichert
  flippedCards.push(card);
  //Wenn erst eine Karte offen ist
  if(flippedCards.length === 1){
    return;
  }
  //zwei Karten sind sichtbar
  moves++;
  document.getElementById("moves").textContent = moves; 
  lockBoard = true;

  //Prüfung ob die Karten gleich sind
  checkForMatch();
}


// Game logic
function checkForMatch() {
  //Vergleicht, ob die Karten gleich sind
  const card1 = flippedCards[0];
  const card2 = flippedCards[1];
  const isMatch = card1.getAttribute("data-value") === card2.getAttribute("data-value");
//hier frage ich an wenn die Elemente passen dann wird sonst wird es wieder geflipped
  if(isMatch){
    console.log("Match gefunden!");
    //die Karten werden als gefunden gekennzeichnet
    card1.classList.add("matched"); // fügt die sss klasse hinzu
    card2.classList.add("matched");
    //Anzahl wird erhöht 
    matches++;
    //die Auswahl wird geleert
    clearSelection();
    checkWin();
  } else {
    //wenn kein paar gefunden wurde kann die Karten wieder nach einer Zeit verstecken
  setTimeout(() => {
    card1.textContent = "?";
    card2.textContent = "?";
    card1.classList.remove("flipped"); //entfernt die Klasse
    card2.classList.remove("flipped");
    clearSelection();
  }, 700);
}
}

//stopTimer - Funktion redundanz vermeidung

function stopTimer(){
  clearInterval(timer);
  timer = null;
}
//funktion für den Gewinn mit einem dynamischen Stil
function checkWin() {
  if (matches === totalPairs) {
    const msg = document.getElementById("message");
    msg.textContent = "You won! All matches found.";    
    msg.style.fontSize = "40px";
    msg.style.color = "#353232";
    msg.style.fontWeight = "bold";

  stopTimer();
    
    console.log("Sieg-Animation gestartet.");
  }
}

// Reset
function clearSelection(){
 flippedCards = [];
 lockBoard = false;
}
//timer startet wenn die erste Karte geflipped ist 

let time = 0;
let timer = null;

function starttimer() {
  if(timer != null) return;
//die Zeit wird mit der Funktion setInterval erhöht
  timer = setInterval(function(){
    time++;
    //Anzeige
    document.getElementById("time").textContent = time;
  }, 1000);
  }

  //Spiel wird zurückgesetzt
function resetGame(){
  matches = 0;
  moves = 0;
  flippedCards = [];
  lockBoard = false;
  stopTimer();
  time = 0;
//Gewinnnachricht wird geleert
  document.getElementById("message").textContent = "";
  //Anzeige für Moves auf 0 setzen
  document.getElementById("moves").textContent = "0";
  document.getElementById("time").textContent = "0";

  shuffleArray(cardIcons);
  createBoard();
}
//Eventlistener zu den Reset Button hinzugefügt, wenn der button geklickt wird kann wird der Reset executed
document.getElementById("resetBtn").addEventListener("click", resetGame);
resetGame();
